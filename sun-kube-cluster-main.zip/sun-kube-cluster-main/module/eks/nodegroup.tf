resource "aws_iam_role" "global-node-group-role" {
  name = "node-group-role"

  assume_role_policy = jsonencode({
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "ec2.amazonaws.com"
      }
    }]
    Version = "2012-10-17"
  })
}

resource "aws_iam_role_policy_attachment" "global-eks-worker-policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
  role       = aws_iam_role.global-node-group-role.name
}

resource "aws_iam_role_policy_attachment" "global-eks-cni-policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
  role       = aws_iam_role.global-node-group-role.name
}

resource "aws_iam_role_policy_attachment" "global-eks-container-policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
  role       = aws_iam_role.global-node-group-role.name
}


resource "aws_eks_node_group" "global-node-group" {
  cluster_name = aws_eks_cluster.global-cluster.name
  node_group_name = "worker-node"
  node_role_arn = aws_iam_role.global-node-group-role.arn
  subnet_ids = [aws_subnet.pubsub01.id, aws_subnet.pubsub02.id] #aws_subnet.pri01.id, aws_subnet.pri02.id]
  instance_types = ["t3.medium"]
  version = aws_eks_cluster.global-cluster.version
  scaling_config {
    desired_size = 3
    min_size = 3
    max_size = 4
  }
  update_config {
      max_unavailable = 1 #4nodes -> 3 should be available 
    }
  labels = {
    zone = "west"
  }
  depends_on = [
    aws_iam_role_policy_attachment.global-eks-cni-policy,
    aws_iam_role_policy_attachment.global-eks-container-policy,
    aws_iam_role_policy_attachment.global-eks-worker-policy,
  ]
}


#upgrade : 

# resource "aws_eks_node_group" "global-node-group" {
#   cluster_name = aws_eks_cluster.global-cluster.name
#   node_group_name = "worker-node"
#   node_role_arn = aws_iam_role.global-node-group-role.arn
#   subnet_ids = [aws_subnet.pubsub01.id, aws_subnet.pubsub02.id] #aws_subnet.pri01.id, aws_subnet.pri02.id]
#   instance_types = ["t2.medium"]
#   version = aws_eks_cluster.global-cluster.version
#   scaling_config {
#     desired_size = 3
#     min_size = 3
#     max_size = 6
#   }
#   update_config {
#     max_unavailable = 1
#   }
#   labels = {
#     zone = "west"
#   }
#   depends_on = [
#     aws_iam_role_policy_attachment.global-eks-cni-policy,
#     aws_iam_role_policy_attachment.global-eks-container-policy,
#     aws_iam_role_policy_attachment.global-eks-worker-policy,
#   ]
# }
